package com.example.ecommerceapp.prevalent;
import com.example.ecommerceapp.model.Users;
public class prevalent {
    public static Users CurrentOnlineUser;
    public static final String UserPhoneKey="UserPhone";
    public  static final String UserPasswordKey="Userpassword";
}
